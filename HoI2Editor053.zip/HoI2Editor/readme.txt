Alternative HoI2 Editor Ver 0.53

- What is this?

A data editor for DH, AoD, and HoI2DDA.
It supports editing leaders, ministers, tech teams, provinces,
tech trees, unit models, misc settings, unit names, unit model names,
corps names, random leader names, and scenarios.
It also supports moddir.

- How to use?

1. Install .NET Framework 3.5
2. Decompress the archive and place .exe file to some folder.
3. Launch .exe file.
4. Drag and drop a game folder to the editor's window, and editor buttons are active.
5. Press editor buttons and individual editors are launched.
6. If you have finished editing, press Save button and exit.

- Disclaimer

Please use this at your own risk.
You should backup your game files first.
